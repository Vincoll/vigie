# DNS Probe

**RFC:** [RFC1035](https://www.ietf.org/rfc/rfc1035.txt)


---
Timeout : 5sec
6.1.3.3 (5) https://tools.ietf.org/rfcmarkup?doc=1123#page-77
---